let lastText = "";

const observer = new MutationObserver((mutations, obs) => {
  // 넷플릭스 자막 요소를 더 포괄적으로 탐색
  const subtitleNode = document.querySelector('.player-timedtext') || 
                       document.querySelector('.watch-video--timed-text-container');
  
  if (subtitleNode) {
    // innerText를 줄바꿈 기준으로 나누어 처리합니다.
    let currentText = (subtitleNode.innerText || subtitleNode.textContent)
      .replace(/^- /gm, ', ')           // 화자 구분 대시는 쉼표로 바꾸어 약간의 휴지기 부여
      .replace(/^-/gm, '')              // 나머지 대시 제거
      .split('\n')                      // 줄바꿈 기준으로 분리
      .map(t => t.trim())
      .filter(t => t.length > 0)
      .join(' ')                        // 문장을 먼저 하나로 합침 (단어 끊김 방지)
      .replace(/\s+/g, ' ')             // 다중 공백 정리
      .trim();

    if (currentText.length > 0) {
      // 의문형 어미(~까, ~죠, ~요, ~니, ~나)로 끝나는데 부호가 없으면 물음표 추가
      if (!/[.?!,;~"'\)\]]$/.test(currentText) && /[까죠요니나]$/.test(currentText)) {
        currentText += '?';
      } else if (!/[.?!,;~"'\)\]]$/.test(currentText)) {
        currentText += '.';
      }
      
      // 물음표 앞에 공백을 하나 넣으면 많은 TTS 엔진이 '상승 조'를 더 잘 표현합니다.
      currentText = currentText.replace(/\?/g, ' ?');
    }

    if (currentText && currentText !== lastText && currentText.length > 0) {
      lastText = currentText;
      
      try {
        if (chrome.runtime?.id) {
          console.log("[SubtitleReader] 자막 감지됨:", currentText);
          chrome.runtime.sendMessage({ type: "SPEAK_SUBTITLE", text: currentText });
        }
      } catch (e) {
        console.log("[SubtitleReader] 연결이 끊겼습니다. 페이지를 새로고침하세요.");
        obs.disconnect(); // 고립된 컨텍스트에서 관찰 중단
      }
    }
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});